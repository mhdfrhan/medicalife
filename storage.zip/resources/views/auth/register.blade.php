<x-guest-layout>

	@livewire('auth.register')

</x-guest-layout>
