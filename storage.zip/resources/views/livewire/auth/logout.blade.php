<div wire:click='logout' >

        Logout
</div>
