<x-guest-layout>

	
	@livewire('auth.login')


</x-guest-layout>
